// Load the http module to create an http server.
var http = require('http');

var exec = require('child_process').exec;

// Configure our HTTP server to respond with Hello World to all requests.
var server = http.createServer(function (request, response) {
  var child = exec('/usr/bin/candump -n 5 can0',function(err, stdout, stderr) {
    if(err) {
       	response.writeHead(200, {"Content-Type": "text/plain"});
     	response.end("Hello ionoid\n");

    } else {
        response.writeHead(200, {"Content-Type": "text/plain"});
  	response.end(stdout.toString());
    }
  });
});

// Listen on port 8000
server.listen(8000, "0.0.0.0");

// Put a friendly message on the terminal
console.log("Server running at http://0.0.0.0:8000/");
